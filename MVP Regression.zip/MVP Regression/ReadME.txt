This is a python skit-learn project that includes a multitude of different files that
work together. The first part of the project was webscraping, which was done in the
MVP data scraping.ipynb file which used python requests and python selenium to scrape
data from 3 different webpages under the same website. The second part was data cleaning,
which was done in the data cleaning.ipynb to create a final merged csv called
PlayerMVPstats.csv. The final part was the prediction algorithm which was done in
MVP predictor.ipynb. This file has all details and thought processes documented when
going about this research project. Thank you!